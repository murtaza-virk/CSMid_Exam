package com.vsn.firebasetaks.RetroFit;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class listData {


    @Expose
    @SerializedName("userId")
    private String userId;

    @Expose
    @SerializedName("title")
    private String title;


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
