package com.vsn.firebasetaks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.vsn.firebasetaks.RetroFit.APIClient;
import com.vsn.firebasetaks.RetroFit.listData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
            LoadData();


    }

    public void LoadData(){

        Call<List<listData>> listData = APIClient.getInstance().getApi().getImpValues();


        listData.enqueue(new Callback<List<listData>>() {
            @Override
            public void onResponse(Call<List<listData>> call, Response<List<listData>> response) {
                List<listData> values = response.body();
                List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                for (int i=0; i<values.size(); i++) {
                    Map<String, String> datum = new HashMap<String, String>(2);
                    datum.put("id", values.get(i).getUserId());
                    datum.put("title", values.get(i).getTitle());
                    data.add(datum);
                }
                SimpleAdapter adapter = new SimpleAdapter(MainActivity.this, data,
                        android.R.layout.simple_list_item_2,
                        new String[] {"id", "title"},
                        new int[] {android.R.id.text1,
                                android.R.id.text2});
                listView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<listData>> call, Throwable t) {
                Toast.makeText(MainActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}